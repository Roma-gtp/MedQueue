#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  interpreter=""
  for candidate in python3.13 python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2>/dev/null; then
      interpreter="$candidate"
      break
    fi
  done
  if [ -z "$interpreter" ]; then
    echo 'Установите Python 3.11 или новее, затем запустите этот файл снова.'
    read -r -p 'Нажмите Enter для выхода…'
    exit 1
  fi
  "$interpreter" -m venv .venv
fi
if ! .venv/bin/python -c 'import fastapi, pydantic, uvicorn' >/dev/null 2>&1; then
  .venv/bin/python -m pip install -r requirements.txt
fi
printf '\nMedQueue: http://127.0.0.1:8017\nОткройте ссылку в браузере. Для остановки: Ctrl+C.\n\n'
exec .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8017
