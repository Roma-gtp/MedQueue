"""Local educational clinic scheduling API. All people are synthetic."""
import os
import sqlite3
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .database import SLOTS, TRANSITIONS, TZ, connection, initialize, rows, today

ROOT = Path(__file__).resolve().parents[1]
Status = Literal["scheduled", "arrived", "in_progress", "completed", "cancelled"]


class Booking(BaseModel):
    model_config = ConfigDict(extra="forbid")
    doctor_id: int = Field(gt=0, strict=True)
    patient_id: int = Field(gt=0, strict=True)
    date: date
    time: str = Field(pattern=r"^\d{2}:\d{2}$")


class StatusChange(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Status


def create_app(db_path=None):
    path = Path(db_path or os.environ.get("MEDQUEUE_DB", ROOT / "data" / "medqueue.sqlite3"))

    @asynccontextmanager
    async def lifespan(app):
        initialize(path)
        yield

    app = FastAPI(title="MedQueue API", version="1.0.0", lifespan=lifespan,
                  description="Учебная регистратура. Только синтетические данные. Время Asia/Almaty.")
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "testserver"])

    @app.middleware("http")
    async def local_requests(request: Request, call_next):
        # Reject cross-site mutations; this is not user authentication.
        if request.method in {"POST", "PATCH", "DELETE", "PUT"}:
            origin = request.headers.get("origin")
            if origin and origin != str(request.base_url).rstrip("/"):
                return JSONResponse({"detail": "Запрос с другого сайта запрещён"}, status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        if request.url.path == "/":
            response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        return response

    def ensure_doctor(db, doctor_id):
        if not db.execute("SELECT 1 FROM doctors WHERE id=?", (doctor_id,)).fetchone():
            raise HTTPException(404, "Врач не найден")

    @app.get("/api/health")
    def health():
        with connection(path) as db:
            db.execute("SELECT 1 FROM metadata").fetchone()
        return {"status": "ok", "demo": True}

    @app.get("/api/config")
    def config():
        with connection(path) as db:
            demo = db.execute("SELECT value FROM metadata WHERE key='demo_date'").fetchone()[0]
        return {"today": today().isoformat(), "max_date": (today()+timedelta(days=90)).isoformat(),
                "demo_date": demo, "timezone": "Asia/Almaty", "slot_minutes": 30}

    @app.get("/api/doctors")
    def doctors():
        with connection(path) as db:
            return rows(db, "SELECT * FROM doctors ORDER BY id")

    @app.get("/api/patients")
    def patients():
        with connection(path) as db:
            return rows(db, "SELECT * FROM patients ORDER BY id")

    @app.get("/api/slots")
    def slots(date: date, doctor_id: int = Query(gt=0)):
        with connection(path) as db:
            ensure_doctor(db, doctor_id)
            occupied = {r[0] for r in db.execute("SELECT time FROM appointments WHERE doctor_id=? AND date=? AND status!='cancelled'", (doctor_id, date.isoformat()))}
        valid = today() <= date <= today()+timedelta(days=90) and date.weekday() < 5
        return {"date": date.isoformat(), "slots": [s for s in SLOTS if s not in occupied] if valid else []}

    @app.get("/api/appointments")
    def appointments(date: date, doctor_id: int | None = Query(default=None, gt=0), status: Status | None = None):
        query = """SELECT a.*,d.name doctor_name,d.specialty,d.room,p.name patient_name
                   FROM appointments a JOIN doctors d ON d.id=a.doctor_id
                   JOIN patients p ON p.id=a.patient_id WHERE a.date=?"""
        values = [date.isoformat()]
        with connection(path) as db:
            if doctor_id is not None:
                ensure_doctor(db, doctor_id)
                query += " AND a.doctor_id=?"
                values.append(doctor_id)
            if status:
                query += " AND a.status=?"
                values.append(status)
            return rows(db, query + " ORDER BY a.time,a.doctor_id,a.id", values)

    @app.post("/api/appointments", status_code=201)
    def book(booking: Booking):
        if not today() <= booking.date <= today()+timedelta(days=90):
            raise HTTPException(422, "Выберите дату от сегодня до 90 дней вперёд")
        if booking.date.weekday() > 4 or booking.time not in SLOTS:
            raise HTTPException(422, "Приём: пн–пт, 09:00–17:00, перерыв 12:00–13:00; шаг 30 минут")
        with connection(path) as db:
            ensure_doctor(db, booking.doctor_id)
            if not db.execute("SELECT 1 FROM patients WHERE id=?", (booking.patient_id,)).fetchone():
                raise HTTPException(404, "Пациент не найден")
            now = datetime.now(TZ).isoformat()
            try:
                result = db.execute("INSERT INTO appointments(doctor_id,patient_id,date,time,created_at) VALUES(?,?,?,?,?)",
                                    (booking.doctor_id, booking.patient_id, booking.date.isoformat(), booking.time, now))
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Слот уже занят или у пациента есть запись на это время") from None
            db.execute("INSERT INTO audit(appointment_id,from_status,to_status,changed_at) VALUES(?,NULL,'scheduled',?)", (result.lastrowid, now))
            return dict(db.execute("SELECT * FROM appointments WHERE id=?", (result.lastrowid,)).fetchone())

    @app.patch("/api/appointments/{appointment_id}")
    def change_status(appointment_id: int, change: StatusChange):
        with connection(path) as db:
            # Serialize read/validate/write so stale requests cannot overwrite a newer state.
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT * FROM appointments WHERE id=?", (appointment_id,)).fetchone()
            if current is None:
                raise HTTPException(404, "Запись не найдена")
            if change.status not in TRANSITIONS[current["status"]]:
                raise HTTPException(409, "Этот переход статуса недоступен. Обновите расписание")
            try:
                db.execute("UPDATE appointments SET status=? WHERE id=?", (change.status, appointment_id))
            except sqlite3.IntegrityError:
                raise HTTPException(409, "У врача уже идёт приём. Сначала завершите его") from None
            db.execute("INSERT INTO audit(appointment_id,from_status,to_status,changed_at) VALUES(?,?,?,?)",
                       (appointment_id, current["status"], change.status, datetime.now(TZ).isoformat()))
            return dict(db.execute("SELECT * FROM appointments WHERE id=?", (appointment_id,)).fetchone())

    @app.get("/api/appointments/{appointment_id}/history")
    def history(appointment_id: int):
        with connection(path) as db:
            if not db.execute("SELECT 1 FROM appointments WHERE id=?", (appointment_id,)).fetchone():
                raise HTTPException(404, "Запись не найдена")
            return rows(db, "SELECT * FROM audit WHERE appointment_id=? ORDER BY id", (appointment_id,))

    @app.get("/api/summary")
    def summary(date: date):
        with connection(path) as db:
            counts = {s: 0 for s in TRANSITIONS}
            counts.update({r[0]: r[1] for r in db.execute("SELECT status,COUNT(*) FROM appointments WHERE date=? GROUP BY status", (date.isoformat(),))})
            load = rows(db, """SELECT d.id,d.name,d.specialty,d.room,COUNT(a.id) booked
                FROM doctors d LEFT JOIN appointments a ON a.doctor_id=d.id AND a.date=? AND a.status!='cancelled'
                GROUP BY d.id ORDER BY d.id""", (date.isoformat(),))
        capacity = len(SLOTS) if date.weekday() < 5 else 0
        for doctor in load:
            doctor.update(capacity=capacity, percent=round(doctor["booked"] / capacity * 100) if capacity else 0)
        return {"date": date.isoformat(), "counts": counts, "total": sum(counts.values()),
                "active": sum(v for k, v in counts.items() if k != "cancelled"), "doctors": load}

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(ROOT / "static" / "index.html")

    app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
    return app


app = create_app()
