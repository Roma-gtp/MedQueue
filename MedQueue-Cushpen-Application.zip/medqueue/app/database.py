"""SQLite repository: constraints protect bookings across concurrent requests."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Almaty")
SLOTS = [f"{hour:02d}:{minute:02d}" for hour in range(9, 17) if hour != 12 for minute in (0, 30)]
TRANSITIONS = {
    "scheduled": {"arrived", "cancelled"},
    "arrived": {"in_progress", "cancelled"},
    "in_progress": {"completed"},
    "completed": set(),
    "cancelled": set(),
}


def today():
    return datetime.now(TZ).date()


@contextmanager
def connection(path):
    db = sqlite3.connect(str(path), timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def initialize(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with connection(path) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL,
            specialty TEXT NOT NULL, room TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY, doctor_id INTEGER NOT NULL REFERENCES doctors(id),
            patient_id INTEGER NOT NULL REFERENCES patients(id),
            date TEXT NOT NULL, time TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'scheduled'
                CHECK(status IN ('scheduled','arrived','in_progress','completed','cancelled')),
            created_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS doctor_slot
            ON appointments(doctor_id, date, time) WHERE status != 'cancelled';
        CREATE UNIQUE INDEX IF NOT EXISTS patient_slot
            ON appointments(patient_id, date, time) WHERE status != 'cancelled';
        CREATE UNIQUE INDEX IF NOT EXISTS doctor_in_progress
            ON appointments(doctor_id, date) WHERE status = 'in_progress';
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY, appointment_id INTEGER NOT NULL REFERENCES appointments(id),
            from_status TEXT, to_status TEXT NOT NULL, changed_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        # Seed once, never reset the user's bookings at startup.
        db.execute("BEGIN IMMEDIATE")
        if db.execute("SELECT 1 FROM metadata WHERE key='seeded'").fetchone():
            return
        db.executemany("INSERT INTO doctors VALUES (?,?,?,?)", [
            (1, "Врач A", "Терапевт", "101"),
            (2, "Врач B", "Кардиолог", "204"),
            (3, "Врач C", "Невролог", "208"),
        ])
        db.executemany("INSERT INTO patients VALUES (?,?)", [(i, f"Демо-пациент {i:02d}") for i in range(1, 13)])
        demo_date = today()
        while demo_date.weekday() > 4:
            demo_date += timedelta(days=1)
        now = datetime.now(TZ).isoformat()
        seed = [(1, 1, "09:00", "completed"), (1, 2, "09:30", "in_progress"),
                (1, 3, "10:00", "arrived"), (1, 4, "10:30", "scheduled"),
                (2, 5, "09:00", "completed"), (2, 6, "10:00", "arrived"),
                (2, 7, "11:00", "scheduled"), (3, 8, "09:30", "scheduled"),
                (3, 9, "11:30", "cancelled")]
        for doctor, patient, time, status in seed:
            row = db.execute("INSERT INTO appointments(doctor_id,patient_id,date,time,status,created_at) VALUES(?,?,?,?,?,?)",
                             (doctor, patient, demo_date.isoformat(), time, status, now))
            db.execute("INSERT INTO audit(appointment_id,from_status,to_status,changed_at) VALUES(?,NULL,?,?)",
                       (row.lastrowid, status, now))
        db.executemany("INSERT INTO metadata VALUES(?,?)", [("seeded", "1"), ("demo_date", demo_date.isoformat())])


def rows(db, query, values=()):
    return [dict(row) for row in db.execute(query, values)]
