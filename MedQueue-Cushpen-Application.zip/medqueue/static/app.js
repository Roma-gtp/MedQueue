'use strict';
const $ = (id) => document.getElementById(id);
const labels = {scheduled:'Записан',arrived:'В ожидании',in_progress:'На приёме',completed:'Завершён',cancelled:'Отменён'};
const actions = {scheduled:[['arrived','Пришёл'],['cancelled','Отменить']],arrived:[['in_progress','Начать'],['cancelled','Отменить']],in_progress:[['completed','Завершить']],completed:[],cancelled:[]};
let config, doctors=[], requestVersion=0, slotVersion=0, toastTimer;
function el(tag, className, text) { const e=document.createElement(tag); if(className)e.className=className; if(text!==undefined)e.textContent=text; return e; }
function showError(id, message) { $(id).textContent=message||''; $(id).hidden=!message; }
function toast(message) { $('toast').textContent=message; $('toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').hidden=true,4500); }
async function api(url, options={}) {
  const response=await fetch(url,{...options,headers:{'Content-Type':'application/json',...options.headers}});
  if(!response.ok) {
    const data=await response.json().catch(()=>({}));
    throw new Error(typeof data.detail==='string'?data.detail:`Не удалось выполнить запрос (${response.status}). Проверьте поля и повторите.`);
  }
  return response.json();
}
function option(value,text) { const e=el('option','',text); e.value=value; return e; }
function formatDate(value) { return new Date(value+'T12:00:00').toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}); }
function addDays(value,delta) {const d=new Date(value+'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+delta); return d.toISOString().slice(0,10);}
async function loadDay() {
  const current=++requestVersion;
  if(!$('view-date').value) {showError('page-error','Выберите дату расписания.');return;}
  const params=new URLSearchParams({date:$('view-date').value});
  if($('doctor-filter').value)params.set('doctor_id',$('doctor-filter').value);
  if($('status-filter').value)params.set('status',$('status-filter').value);
  $('appointments').setAttribute('aria-busy','true');
  showError('page-error','');
  try {
    const [appointments,summary]=await Promise.all([api('/api/appointments?'+params),api('/api/summary?date='+$('view-date').value)]);
    if(current!==requestVersion)return;
    renderAppointments(appointments);renderSummary(summary);
    $('schedule-caption').textContent=formatDate(summary.date)+' · время Астаны';
    $('day-label').textContent=new Date(summary.date+'T12:00:00').toLocaleDateString('ru-RU',{weekday:'long'});
  } catch(error) {
    if(current!==requestVersion)return;
    showError('page-error',error.message);$('appointments').replaceChildren();$('doctors-load').replaceChildren();
    for(const id of ['total','waiting','progress','completed'])$('metric-'+id).textContent='—';
    $('schedule-caption').textContent='Расписание недоступно';$('result-count').textContent='';$('empty').hidden=true;
  } finally {if(current===requestVersion)$('appointments').setAttribute('aria-busy','false');}
}
function renderAppointments(items) {
  $('appointments').replaceChildren();$('empty').hidden=items.length>0;
  $('result-count').textContent=`Показано: ${items.length}`;
  for(const item of items) {
    const tr=el('tr'); const time=el('td','time',item.time);time.append(el('small','subtext','30 минут'));
    const patient=el('td','patient',item.patient_name);patient.append(el('small','subtext',`Запись #${String(item.id).padStart(3,'0')}`));
    const doctor=el('td','',item.specialty);doctor.append(el('small','subtext',`${item.doctor_name} · каб. ${item.room}`));
    const status=el('td');status.append(el('span','status status-'+item.status,labels[item.status]));
    const buttons=el('td');const row=el('div','row-actions');
    for(const [next,label] of actions[item.status]) {
      const button=el('button','action'+(next==='cancelled'?' cancel':''),label);
      button.setAttribute('aria-label',`${label}: ${item.patient_name}, ${item.time}`);
      button.addEventListener('click',async()=>{
        if(next==='cancelled'&&!window.confirm(`Отменить запись: ${item.patient_name}, ${item.time}?`))return;
        for(const b of row.querySelectorAll('button'))b.disabled=true;
        try {await api('/api/appointments/'+item.id,{method:'PATCH',body:JSON.stringify({status:next})});toast('Статус обновлён: '+labels[next]);}
        catch(error){toast(error.message);}
        await loadDay();
      });row.append(button);
    }
    const history=el('button','action history-button','⋯');history.setAttribute('aria-label',`История записи ${item.patient_name}`);history.title='История записи';history.addEventListener('click',()=>showHistory(item));row.append(history);buttons.append(row);
    tr.append(time,patient,doctor,status,buttons);$('appointments').append(tr);
  }
}
function renderSummary(summary) {
  $('metric-total').textContent=summary.total;$('metric-waiting').textContent=summary.counts.arrived;
  $('metric-progress').textContent=summary.counts.in_progress;$('metric-completed').textContent=summary.counts.completed;
  $('doctors-load').replaceChildren();
  for(const doctor of summary.doctors) {
    const card=el('div','doctor-load'),line=el('div','doctor-line'),avatar=el('span','doctor-avatar',doctor.name.slice(-1));
    const info=el('div','doctor-info',doctor.name);info.append(el('small','',doctor.specialty+' · каб. '+doctor.room));line.append(avatar,info,el('strong','',doctor.percent+'%'));
    const progress=el('progress','progress');progress.max=100;progress.value=doctor.percent;progress.setAttribute('aria-label','Загрузка '+doctor.name);
    const caption=el('div','load-caption');caption.append(el('span','',`${doctor.booked} из ${doctor.capacity} интервалов`),el('span','',doctor.capacity?'за день':'выходной'));
    card.append(line,progress,caption);$('doctors-load').append(card);
  }
}
async function loadSlots() {
  const current=++slotVersion;$('booking-time').replaceChildren(option('','Загрузка…'));$('save-booking').disabled=true;
  try {
    if(!$('booking-date').value||!$('booking-doctor').value){$('booking-time').replaceChildren(option('','Выберите дату и врача'));return;}
    const result=await api('/api/slots?'+new URLSearchParams({date:$('booking-date').value,doctor_id:$('booking-doctor').value}));
    if(current!==slotVersion)return;
    $('booking-time').replaceChildren(option('',result.slots.length?'Выберите время':'Свободных интервалов нет'));
    for(const time of result.slots)$('booking-time').append(option(time,time));
    $('save-booking').disabled=!result.slots.length;
  }catch(error){if(current===slotVersion){$('booking-time').replaceChildren(option('','Время недоступно'));showError('booking-error',error.message);}}
}
async function showHistory(item) {
  $('history-title').textContent='История записи #'+item.id;$('history-list').replaceChildren(el('li','','Загрузка…'));$('history-dialog').showModal();
  try {const history=await api(`/api/appointments/${item.id}/history`);$('history-list').replaceChildren();for(const event of history){const li=el('li','',(event.from_status?labels[event.from_status]+' → ':'Создана: ')+labels[event.to_status]);li.append(el('small','',new Date(event.changed_at).toLocaleString('ru-RU',{timeZone:'Asia/Almaty'})+' · Asia/Almaty'));$('history-list').append(li);}}
  catch(error){$('history-list').replaceChildren(el('li','error',error.message));}
}
$('open-booking').disabled=true;
$('open-booking').addEventListener('click',()=>{
  showError('booking-error','');$('booking-form').reset();
  $('booking-date').value=$('view-date').value>=config.today&&$('view-date').value<=config.max_date?$('view-date').value:config.today;
  if($('doctor-filter').value)$('booking-doctor').value=$('doctor-filter').value;
  $('booking-dialog').showModal();loadSlots();
});
for(const button of document.querySelectorAll('[data-close]'))button.addEventListener('click',()=>$(button.dataset.close).close());
for(const id of ['booking-doctor','booking-date'])$(id).addEventListener('change',()=>{showError('booking-error','');loadSlots();});
$('booking-form').addEventListener('submit',async event=>{
  event.preventDefault();if(!$('booking-form').reportValidity())return;$('save-booking').disabled=true;showError('booking-error','');
  const value={doctor_id:Number($('booking-doctor').value),patient_id:Number($('booking-patient').value),date:$('booking-date').value,time:$('booking-time').value};
  try {await api('/api/appointments',{method:'POST',body:JSON.stringify(value)});$('booking-dialog').close();$('view-date').value=value.date;$('doctor-filter').value='';$('status-filter').value='';await loadDay();toast('Пациент записан на '+value.time);}
  catch(error){showError('booking-error',error.message);await loadSlots();}
  finally {if(!$('booking-dialog').open)$('save-booking').disabled=false;}
});
for(const id of ['view-date','doctor-filter','status-filter'])$(id).addEventListener('change',loadDay);
$('prev-day').addEventListener('click',()=>{if(!$('view-date').value)return;$('view-date').value=addDays($('view-date').value,-1);loadDay();});
$('next-day').addEventListener('click',()=>{if(!$('view-date').value)return;$('view-date').value=addDays($('view-date').value,1);loadDay();});
$('today').addEventListener('click',()=>{if(config){$('view-date').value=config.today;loadDay();}});
$('demo-day').addEventListener('click',()=>{if(config){$('view-date').value=config.demo_date;loadDay();}});
$('refresh').addEventListener('click',()=>config?loadDay():init());
async function init() {
  try {
    const data=await Promise.all([api('/api/config'),api('/api/doctors'),api('/api/patients')]);
    config=data[0];doctors=data[1];$('view-date').value=config.demo_date;
    $('doctor-filter').replaceChildren(option('','Все врачи'));$('booking-doctor').replaceChildren();$('booking-patient').replaceChildren();
    for(const doctor of doctors){$('doctor-filter').append(option(doctor.id,doctor.specialty+' · '+doctor.name));$('booking-doctor').append(option(doctor.id,doctor.specialty+' · '+doctor.name));}
    for(const patient of data[2])$('booking-patient').append(option(patient.id,patient.name));
    $('booking-date').min=config.today;$('booking-date').max=config.max_date;$('open-booking').disabled=false;await loadDay();
  }catch(error){showError('page-error','Не удалось загрузить данные. '+error.message);}
}
init();
