"""Behavioral tests with an isolated SQLite database, including concurrent writes."""
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from pathlib import Path
from fastapi.testclient import TestClient
from app.database import SLOTS, connection, today
from app.main import create_app

class ClinicTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'test.sqlite3'
        self.app = create_app(self.path)
        self.client = TestClient(self.app)
        self.client.__enter__()
        day = today() + timedelta(days=7)
        while day.weekday() > 4:
            day += timedelta(days=1)
        self.day = day.isoformat()
        self.booking = dict(doctor_id=1, patient_id=10, date=self.day, time='14:00')
    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.temp.cleanup()
    def book(self, **overrides):
        return self.client.post('/api/appointments', json=self.booking | overrides)
    def test_demo_counts_match_records(self):
        day = self.client.get('/api/config').json()['demo_date']
        records = self.client.get('/api/appointments', params={'date': day}).json()
        summary = self.client.get('/api/summary', params={'date': day}).json()
        self.assertEqual(summary['total'], len(records))
        self.assertEqual(summary['active'], len([r for r in records if r['status'] != 'cancelled']))
        self.assertEqual(sum(d['booked'] for d in summary['doctors']), summary['active'])
    def test_full_lifecycle_and_history(self):
        created = self.book()
        self.assertEqual(created.status_code, 201)
        record = created.json()['id']
        for state in ['arrived', 'in_progress', 'completed']:
            result = self.client.patch(f'/api/appointments/{record}', json={'status': state})
            self.assertEqual(result.status_code, 200, result.text)
        history = self.client.get(f'/api/appointments/{record}/history').json()
        self.assertEqual([e['to_status'] for e in history], ['scheduled', 'arrived', 'in_progress', 'completed'])
        self.assertEqual(self.client.patch(f'/api/appointments/{record}', json={'status': 'cancelled'}).status_code, 409)
    def test_doctor_conflict(self):
        self.assertEqual(self.book().status_code, 201)
        self.assertEqual(self.book(patient_id=11).status_code, 409)
    def test_patient_conflict_across_doctors(self):
        self.assertEqual(self.book().status_code, 201)
        self.assertEqual(self.book(doctor_id=2).status_code, 409)
    def test_cancellation_releases_slot(self):
        record = self.book().json()['id']
        params = {'date': self.day, 'doctor_id': 1}
        self.assertNotIn('14:00', self.client.get('/api/slots', params=params).json()['slots'])
        self.assertEqual(self.client.patch(f'/api/appointments/{record}', json={'status': 'cancelled'}).status_code, 200)
        self.assertIn('14:00', self.client.get('/api/slots', params=params).json()['slots'])
        self.assertEqual(self.book().status_code, 201)
    def test_illegal_transition_is_atomic(self):
        record = self.book().json()['id']
        self.assertEqual(self.client.patch(f'/api/appointments/{record}', json={'status': 'completed'}).status_code, 409)
        self.assertEqual(len(self.client.get(f'/api/appointments/{record}/history').json()), 1)
    def test_one_ongoing_visit_per_doctor(self):
        first = self.book().json()['id']
        second = self.book(time='14:30', patient_id=11).json()['id']
        for record in (first, second):
            self.client.patch(f'/api/appointments/{record}', json={'status': 'arrived'})
        self.assertEqual(self.client.patch(f'/api/appointments/{first}', json={'status': 'in_progress'}).status_code, 200)
        self.assertEqual(self.client.patch(f'/api/appointments/{second}', json={'status': 'in_progress'}).status_code, 409)
        self.client.patch(f'/api/appointments/{first}', json={'status': 'completed'})
        self.assertEqual(self.client.patch(f'/api/appointments/{second}', json={'status': 'in_progress'}).status_code, 200)
    def test_invalid_dates_times_and_references(self):
        for time in ['12:00', '12:30', '17:00', '09:15', '99:99']:
            self.assertEqual(self.book(time=time).status_code, 422)
        for day in [today()-timedelta(days=1), today()+timedelta(days=91)]:
            self.assertEqual(self.book(date=day.isoformat()).status_code, 422)
        self.assertEqual(self.book(doctor_id=999).status_code, 404)
        self.assertEqual(self.book(patient_id=999).status_code, 404)
        self.assertEqual(self.book(doctor_id=True).status_code, 422)
        self.assertEqual(self.book(extra='unsupported').status_code, 422)
    def test_weekends_have_no_capacity(self):
        day = today()
        while day.weekday() != 5:
            day += timedelta(days=1)
        self.assertEqual(self.book(date=day.isoformat()).status_code, 422)
        self.assertEqual(self.client.get('/api/slots', params={'date': day.isoformat(), 'doctor_id': 1}).json()['slots'], [])
        self.assertTrue(all(d['capacity'] == 0 for d in self.client.get('/api/summary', params={'date': day.isoformat()}).json()['doctors']))
    def test_filters_and_not_found(self):
        self.book()
        self.assertEqual(self.client.get('/api/appointments', params={'date': self.day, 'doctor_id': 2}).json(), [])
        self.assertEqual(self.client.get('/api/appointments', params={'date': self.day, 'status': 'completed'}).json(), [])
        self.assertEqual(self.client.get('/api/appointments', params={'date': self.day, 'status': 'bogus'}).status_code, 422)
        self.assertEqual(self.client.get('/api/appointments', params={'date': self.day, 'doctor_id': 999}).status_code, 404)
        self.assertEqual(self.client.get('/api/appointments/999/history').status_code, 404)
    def test_parallel_booking_only_one_wins(self):
        def attempt(patient):
            with TestClient(self.app) as client:
                return client.post('/api/appointments', json=self.booking | {'patient_id': patient}).status_code
        with ThreadPoolExecutor(max_workers=2) as executor:
            codes = list(executor.map(attempt, [10, 11]))
        self.assertEqual(sorted(codes), [201, 409])
        with connection(self.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM appointments WHERE date=?', (self.day,)).fetchone()[0], 1)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM audit WHERE appointment_id IN (SELECT id FROM appointments WHERE date=?)', (self.day,)).fetchone()[0], 1)
    def test_restart_preserves_data(self):
        record = self.book().json()['id']
        with TestClient(create_app(self.path)) as another:
            saved = another.get('/api/appointments', params={'date': self.day}).json()
            self.assertEqual([r['id'] for r in saved], [record])
    def test_local_origin_and_static_page(self):
        self.assertEqual(self.client.post('/api/appointments', json=self.booking, headers={'Origin': 'https://other.example'}).status_code, 403)
        self.assertEqual(self.client.post('/api/appointments', json=self.booking, headers={'Origin': 'http://testserver'}).status_code, 201)
        page = self.client.get('/')
        self.assertEqual(page.status_code, 200)
        self.assertIn('MedQueue', page.text)
        self.assertIn("frame-ancestors 'none'", page.headers['content-security-policy'])
        self.assertEqual(self.client.get('/api/health').json()['status'], 'ok')
        self.assertEqual(len(SLOTS), 14)

if __name__ == '__main__':
    unittest.main()
